def main():
    from colonyzer2 import parametryzer

if __name__ == '__main__':
    main()
